<?php
session_start();
require 'config.php';

if ($_POST['login'] && $_POST['password']) {
    $stmt = $pdo->prepare("SELECT * FROM Account WHERE Login = ?");
    $stmt->execute([$_POST['login']]);
    $user = $stmt->fetch();

    if ($user && $user['Password'] === $_POST['password']) {
        $_SESSION['user_id'] = $user['Account_ID'];
        $_SESSION['user_name'] = $user['Full_name'];
        $_SESSION['user_role'] = $user['Account_role'];
        header('Location: index.php');
        exit();
    } else {
        $error = "Неверный логин или пароль";
    }
}
?>

<form method="post">
    <h2>Авторизация</h2>
    <?php if ($error) echo "<p style='color: red'>$error</p>"; ?>
    <input type="text" name="login" placeholder="Логин" required><br>
    <input type="password" name="password" placeholder="Пароль" required><br>
    <button type="submit">Войти</button>
</form>