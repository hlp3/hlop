<?php
session_start();
require 'config.php';

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $full_name = $_POST['full_name'];
    $login = $_POST['login'];
    $password = $_POST['password'];
    $confirm_password = $_POST['confirm_password'];

    if (empty($full_name) || empty($login) || empty($password) || empty($confirm_password)) {
        $error = 'Все поля обязательны для заполнения';
    } elseif ($password !== $confirm_password) {
        $error = 'Пароли не совпадают';
    } else {

        $stmt = $pdo->prepare("SELECT * FROM Account WHERE Login = ?");
        $stmt->execute([$login]);
        if ($stmt->fetch()) {
            $error = 'Пользователь с таким логином уже существует';
        } else {

            $stmt = $pdo->prepare("INSERT INTO Account (Full_name, Login, Password, Account_role) VALUES (?, ?, ?, 1)");
            $stmt->execute([$full_name, $login, $password]);

            header('Location: login.php?registered=1');
            exit;
        }
    }
}
?>

<form method="post">
    <h2>Регистрация</h2>
    <?php if ($error) echo "<p style='color: red'>$error</p>"; ?>
    <input type="text" name="full_name" placeholder="Полное имя" value="<?= htmlspecialchars($full_name ?? '') ?>" required><br>
    <input type="text" name="login" placeholder="Логин" value="<?= htmlspecialchars($login ?? '') ?>" required><br>
    <input type="password" name="password" placeholder="Пароль" required><br>
    <input type="password" name="confirm_password" placeholder="Подтвердите пароль" required><br>
    <button type="submit">Зарегистрироваться</button>
</form>
<p>Уже есть аккаунт? <a href="login.php">Войдите</a></p>