<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php');
    exit();
}
require 'config.php';
?>

<h2>Добро пожаловать, <?= $_SESSION['user_name'] ?>!</h2>
<p>Ваш ID: <?= $_SESSION['user_id'] ?></p>
<p>Ваша роль: <?= $_SESSION['user_role'] ?></p>


<h3>Список продуктов:</h3>
<?php
$products = $pdo->query("SELECT * FROM Products")->fetchAll();
foreach ($products as $product) {
    echo "<div>{$product['Name']} - {$product['Price']} руб.</div>";
}
?>

<a href="logout.php">Выйти</a>